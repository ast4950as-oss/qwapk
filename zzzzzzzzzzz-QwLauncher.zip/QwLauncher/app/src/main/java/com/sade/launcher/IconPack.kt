package com.sade.launcher

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import org.xmlpull.v1.XmlPullParser

/** Standart (ADW/Nova uyumlu) appfilter.xml okuyan basit simge paketi desteği. */
object IconPack {
    class Info(val pkg: String, val label: String)

    private var active: String? = null
    private var res: Resources? = null
    private val byComp = HashMap<String, String>()
    private val byPkg = HashMap<String, String>()
    private var backName: String? = null
    private var scale = 0.78f

    fun available(ctx: Context): List<Info> {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = ArrayList<Info>()
        for (action in arrayOf("org.adw.launcher.THEMES", "com.novalauncher.THEME")) {
            try {
                for (ri in pm.queryIntentActivities(Intent(action), 0)) {
                    val p = ri.activityInfo.packageName
                    if (seen.add(p)) out.add(Info(p, ri.loadLabel(pm).toString()))
                }
            } catch (_: Exception) {}
        }
        return out
    }

    fun load(ctx: Context, pkg: String?) {
        active = null
        res = null
        byComp.clear()
        byPkg.clear()
        backName = null
        scale = 0.78f
        if (pkg.isNullOrEmpty()) return
        try {
            val r = ctx.packageManager.getResourcesForApplication(pkg)
            val parser = android.util.Xml.newPullParser()
            parser.setInput(r.assets.open("appfilter.xml"), "utf-8")
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "item" -> {
                            val c = parser.getAttributeValue(null, "component")
                            val d = parser.getAttributeValue(null, "drawable")
                            if (c != null && d != null) store(c, d)
                        }
                        "iconback" -> backName = parser.getAttributeValue(null, "img1")
                        "scale" -> scale = parser.getAttributeValue(null, "factor")?.toFloatOrNull() ?: 0.78f
                    }
                }
                ev = parser.next()
            }
            res = r
            active = pkg
        } catch (e: Exception) {
            active = null
            res = null
        }
    }

    private fun store(c: String, d: String) {
        val inner = c.removePrefix("ComponentInfo{").removeSuffix("}")
        val slash = inner.indexOf('/')
        if (slash < 0) {
            byPkg[inner] = d
        } else {
            val act = inner.substring(slash + 1)
            if (act == "*") byPkg[inner.substring(0, slash)] = d else byComp[inner] = d
        }
    }

    private fun drawable(name: String): Drawable? {
        val r = res ?: return null
        val p = active ?: return null
        val id = r.getIdentifier(name, "drawable", p)
        if (id == 0) return null
        return try { r.getDrawable(id, null) } catch (e: Exception) { null }
    }

    /** Pakette bu uygulama için özel simge varsa bitmap olarak verir. */
    fun iconFor(componentKey: String, pkg: String, size: Int): Bitmap? {
        if (active == null) return null
        val name = byComp[componentKey] ?: byPkg[pkg] ?: return null
        val d = drawable(name) ?: return null
        return try {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, size, size)
            d.draw(Canvas(bmp))
            bmp
        } catch (e: Exception) { null }
    }

    /** Özel simgesi olmayanlar: paketin yuvarlak zemini üstünde uygulamanın kendi logosu. */
    fun fallback(src: Drawable, size: Int): Bitmap? {
        if (active == null) return null
        val back = backName?.let { drawable(it) } ?: return null
        val raw = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(raw)
        back.setBounds(0, 0, size, size)
        back.draw(c)
        try {
            if (src is AdaptiveIconDrawable) {
                val full = (size * 1.5f * scale).toInt()
                val l = (size - full) / 2
                src.foreground?.let { it.setBounds(l, l, l + full, l + full); it.draw(c) }
            } else {
                val w = (size * scale * 0.85f).toInt()
                val l = (size - w) / 2
                src.setBounds(l, l, l + w, l + w)
                src.draw(c)
            }
        } catch (_: Exception) {}
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = BitmapShader(raw, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawCircle(size / 2f, size / 2f, size / 2f, p)
        return out
    }
}
