package com.sade.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import java.io.File

/** Seçilen duvar kağıdı (yoksa varsayılan dalga arka plan). Paneller de aynı zemini bulanıklaştırır. */
object Wall {
    @Volatile var bitmap: Bitmap? = null
    private const val FILE = "wall.jpg"

    fun load(ctx: Context) {
        bitmap = try {
            val f = File(ctx.filesDir, FILE)
            if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        } catch (e: Exception) { null }
    }

    fun save(ctx: Context, uri: Uri): Boolean = try {
        val dm = ctx.resources.displayMetrics
        val target = maxOf(dm.widthPixels, dm.heightPixels)
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > target * 2) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        if (bmp == null) {
            false
        } else {
            File(ctx.filesDir, FILE).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            bitmap = bmp
            true
        }
    } catch (e: Exception) { false }

    fun reset(ctx: Context) {
        try { File(ctx.filesDir, FILE).delete() } catch (_: Exception) {}
        bitmap = null
    }

    fun make(): Drawable {
        val b = bitmap
        return if (b != null) CropDrawable(b) else WaveBackground()
    }
}

/** Görseli alanı dolduracak şekilde ortadan kırparak çizer. */
class CropDrawable(private val bmp: Bitmap) : Drawable() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val src = Rect()

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val s = maxOf(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        val sw = (b.width() / s).toInt().coerceAtMost(bmp.width)
        val sh = (b.height() / s).toInt().coerceAtMost(bmp.height)
        val l = (bmp.width - sw) / 2
        val t = (bmp.height - sh) / 2
        src.set(l, t, l + sw, t + sh)
        c.drawBitmap(bmp, src, b, paint)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
