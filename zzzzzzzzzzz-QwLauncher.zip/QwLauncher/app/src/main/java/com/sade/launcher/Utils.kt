package com.sade.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.view.ViewGroup
import android.widget.ImageView

/** Görsel efekt ayarları. blur=false: bulanıklık kapalı, paneller daha opak. */
object Fx { @JvmField var blur = true }

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

val INK = 0xFF1E3A5F.toInt()
val SOFT = 0xFF4A6A8A.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Sistem (Material You) vurgu rengi, Android 12+. */
fun Context.accent(): Int = getColor(android.R.color.system_accent1_600)

/** Arayüz ikonu (Lucide, vector drawable); sadece launcher kontrolleri için. */
fun Context.icon(res: Int, sizeDp: Int, color: Int = INK): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(color)
        layoutParams = ViewGroup.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

/** Uygulamanın kendi ikonunu alır, yuvarlatılmış kare (hepsi aynı şekil) bitmap'e çevirir. */
fun roundedIconBitmap(d: Drawable, size: Int): Bitmap {
    val raw = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val rc = Canvas(raw)
    rc.drawColor(Color.WHITE)
    try {
        if (d is AdaptiveIconDrawable) {
            val full = (size * 1.5f).toInt()
            val off = (full - size) / 2
            d.background?.let { it.setBounds(-off, -off, -off + full, -off + full); it.draw(rc) }
            d.foreground?.let { it.setBounds(-off, -off, -off + full, -off + full); it.draw(rc) }
        } else {
            val pad = (size * 0.14f).toInt()
            d.setBounds(pad, pad, size - pad, size - pad)
            d.draw(rc)
        }
    } catch (e: Exception) {
        rc.drawColor(Color.LTGRAY)
    }
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = BitmapShader(raw, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    val r = size * 0.28f
    Canvas(out).drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, p)
    return out
}
