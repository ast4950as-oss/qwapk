package com.sade.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout

/**
 * Arkasındaki arka planın bulanık halini gösteren yuvarlak panel (Android 12+ RenderEffect).
 * İçerik eklerken panelin kendisine değil, içine koyduğun view'lara padding ver.
 * Panelin konumu değiştiyse refresh() çağır.
 */
class BlurPanel(
    ctx: Context,
    radiusDp: Float = 24f,
    blur: Float = 44f,
    tint: Int = Color.argb(95, 255, 255, 255),
    stroke: Int = Color.argb(150, 255, 255, 255)
) : FrameLayout(ctx) {

    private val backdrop = Backdrop(ctx, blur)

    init {
        val d = resources.displayMetrics.density
        val r = radiusDp * d
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        clipToOutline = true

        if (Fx.blur) addView(backdrop, LayoutParams(MATCH, MATCH))

        val a = if (Fx.blur) tint ushr 24 else minOf(255, (tint ushr 24) + 70)
        val tintColor = (tint and 0x00FFFFFF) or (a shl 24)
        val tintView = Fill(ctx)
        tintView.background = GradientDrawable().apply {
            setColor(tintColor)
            setStroke(d.toInt().coerceAtLeast(1), stroke)
            cornerRadius = r
        }
        addView(tintView, LayoutParams(MATCH, MATCH))
    }

    fun refresh() { backdrop.invalidate() }

    /** Panel boyutunu etkilemeyen zemin görünümü: sadece kesin ölçü verilirse dolar, yoksa 0 kalır. */
    private open class Fill(ctx: Context) : View(ctx) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = if (View.MeasureSpec.getMode(widthMeasureSpec) == View.MeasureSpec.EXACTLY)
                View.MeasureSpec.getSize(widthMeasureSpec) else 0
            val h = if (View.MeasureSpec.getMode(heightMeasureSpec) == View.MeasureSpec.EXACTLY)
                View.MeasureSpec.getSize(heightMeasureSpec) else 0
            setMeasuredDimension(w, h)
        }
    }

    private class Backdrop(ctx: Context, blur: Float) : Fill(ctx) {
        private val bg = Wall.make()

        init {
            setRenderEffect(RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP))
        }

        override fun onDraw(canvas: Canvas) {
            var x = 0f
            var y = 0f
            var v: View = this
            while (true) {
                x += v.left + v.translationX
                y += v.top + v.translationY
                v = v.parent as? View ?: break
            }
            bg.setBounds(0, 0, v.width, v.height)
            canvas.save()
            canvas.translate(-x, -y)
            bg.draw(canvas)
            canvas.restore()
        }
    }
}
