plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sade.qwiconpack"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sade.qwiconpack"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Derleme çıktısı iconpack-debug.apk; yanına app-debug.apk adıyla da kopyala
// (GitHub derleme dosyası **/app-debug.apk desenini yüklüyor).
afterEvaluate {
    tasks.matching { it.name == "assembleDebug" }.configureEach {
        doLast {
            val dir = layout.buildDirectory.dir("outputs/apk/debug").get().asFile
            dir.listFiles { f -> f.extension == "apk" && f.name != "app-debug.apk" }
                ?.firstOrNull()
                ?.copyTo(File(dir, "app-debug.apk"), overwrite = true)
        }
    }
}
