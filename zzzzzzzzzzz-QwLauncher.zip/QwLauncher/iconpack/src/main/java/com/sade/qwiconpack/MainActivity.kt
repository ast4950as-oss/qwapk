package com.sade.qwiconpack

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** QwIcons: simge paketinin tanıtım ekranı. Simgeler QwLauncher'dan seçilir. */
class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#E6FBFE")
        window.navigationBarColor = Color.parseColor("#E6FBFE")

        val names = R.drawable::class.java.fields.map { it.name }.filter { it.startsWith("pk_") }.sorted()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        col.addView(TextView(this).apply {
            text = "QwIcons"
            textSize = 30f
            setTextColor(Color.parseColor("#0A5C6B"))
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "${names.size} özel simge · QwLauncher için simge paketi"
            textSize = 14f
            setTextColor(Color.parseColor("#3F7F8C"))
            setPadding(0, dp(4), 0, dp(18))
        })
        col.addView(TextView(this).apply {
            text = "Nasıl kullanılır\n1. QwLauncher'ı aç, ana ekranda boş yere uzun bas.\n" +
                "2. \"Simge paketi\" > \"Kullan: QwIcons\" seç.\n\n" +
                "Özel simgesi olmayan uygulamalar, cyan yuvarlak zemin üzerinde kendi logolarıyla görünür."
            textSize = 14f
            setTextColor(Color.parseColor("#0A5C6B"))
            setLineSpacing(0f, 1.15f)
            setPadding(0, 0, 0, dp(20))
        })

        val grid = GridLayout(this).apply { columnCount = 5 }
        for (n in names) {
            val id = resources.getIdentifier(n, "drawable", packageName)
            if (id == 0) continue
            val iv = ImageView(this)
            try { iv.setImageResource(id) } catch (e: Exception) { continue }
            val lp = GridLayout.LayoutParams()
            lp.width = dp(58)
            lp.height = dp(58)
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            lp.setGravity(Gravity.CENTER)
            grid.addView(iv, lp)
        }
        col.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#E6FBFE"))
            addView(col)
        })
    }
}
