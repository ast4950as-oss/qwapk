# QwLauncher (Android 12+)

1. Android Studio ile bu klasörü aç (File > Open). Gradle sync kendiliğinden yapılır.
2. Telefonda Geliştirici seçenekleri > USB hata ayıklama açık olsun, telefonu bağla, Run (▶).
   APK istersen: Build > Build APK(s).
3. Kurulunca Ana ekran tuşuna bas, "QwLauncher" > "Her zaman" seç
   (veya Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması).

Kullanım: yukarı kaydır veya sol alttaki ızgara ikonuna dokun = tüm uygulamalar.
Çekmecede bir uygulamaya uzun bas = ana ekrana ekle / bilgi / kaldır.

## Yeni özellikler
- Saat kartı: üzerine basıp sürükleyerek istediğin yere taşı (yeri hatırlanır).
- Görev çubuğu: çekmeceden veya ana ekrandan bir uygulamayı sürükleyip çubuğa bırak (en fazla 5).
  Çubuktaki ikonu çubuktan dışarı sürüklersen kalkar; çubuk içinde sürükleyerek sırayı değiştirirsin.
  Bir uygulamaya uzun basıp parmağını kaldırmadan yerinde bırakırsan menü açılır.
- Bildirim paneli: ana ekranda aşağı kaydır veya çubuktaki zil ikonuna dokun.
  İlk seferde "Erişimi aç" ile QwLauncher'a bildirim erişimi ver.
- Ses paneli: çubuktaki hoparlör ikonuna dokun.

## QwIcons (simge paketi)
Aynı projeden iki APK çıkar: `app/` klasöründeki QwLauncher, `iconpack/` klasöründeki QwIcons.
QwIcons'u kur, sonra QwLauncher'da ana ekranda boş yere uzun bas > "Simge paketi" > "Kullan: QwIcons".
