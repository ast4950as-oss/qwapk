package com.sade.launcher

import android.app.Activity
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

data class App(val label: String, val component: ComponentName, val icon: Drawable) {
    val key: String get() = component.flattenToString()
}

private enum class Src { DRAWER, HOME, BAR }
private class DragInfo(val key: String, val src: Src, val anchor: View)
private class MenuItem(val label: String, val action: () -> Unit)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var audio: AudioManager
    private var apps: List<App> = emptyList()

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: FrameLayout
    private lateinit var homeCol: LinearLayout
    private lateinit var clockCard: BlurPanel
    private lateinit var favPanel: BlurPanel
    private lateinit var favGrid: GridLayout
    private lateinit var drawer: FrameLayout
    private lateinit var drawerContent: LinearLayout
    private lateinit var drawerGrid: GridView
    private lateinit var searchEdit: EditText
    private lateinit var taskbar: BlurPanel
    private lateinit var barRow: LinearLayout
    private lateinit var panelLayer: FrameLayout
    private lateinit var sheet: BlurPanel
    private lateinit var notifScroll: ScrollView
    private lateinit var notifList: LinearLayout
    private lateinit var volumeBox: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var clearBtn: TextView
    private lateinit var dragCatcher: View

    private val adapter = AppAdapter()
    private val seekList = ArrayList<Pair<SeekBar, Int>>()
    private var drawerOpen = false
    private var panelOpen = false
    private var panelMode = 0 // 0 = bildirim, 1 = ses
    private var insetTop = 0
    private var insetBottom = 0
    private var drag: DragInfo? = null
    private var imeVisible = false
    private var menuOpen = false
    private lateinit var menuLayer: FrameLayout
    private lateinit var menuCol: LinearLayout
    private lateinit var toastPanel: BlurPanel
    private lateinit var toastText: TextView
    private lateinit var batCard: BlurPanel
    private lateinit var batText: TextView
    private lateinit var batSub: TextView
    private lateinit var batBar: android.widget.ProgressBar
    private lateinit var calCard: BlurPanel
    private lateinit var calGrid: GridLayout
    private lateinit var calTitle: TextView
    private lateinit var recentPanel: BlurPanel
    private lateinit var recentGrid: GridLayout
    private lateinit var indexStrip: LinearLayout
    private lateinit var letterBubble: TextView
    private val barH = 60
    private val maxBar = 5

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("sade", MODE_PRIVATE)
        Fx.blur = prefs.getBoolean("blur", true)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Wall.bitmap == null) Wall.load(this)
        window.setBackgroundDrawable(Wall.make())
        window.setDecorFitsSystemWindows(false)
        buildUi()
        setContentView(root)
        loadApps()
        NotifService.onChange = { runOnUiThread { if (panelOpen && panelMode == 0) refreshNotifs() } }
    }

    override fun onDestroy() {
        super.onDestroy()
        NotifService.onChange = null
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        updateBattery(registerReceiver(batReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
        renderCalendar()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(batReceiver) } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (panelOpen) closePanel()
        if (drawerOpen) closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (menuOpen) closeMenu() else if (panelOpen) closePanel() else if (drawerOpen) closeDrawer()
    }

    // ================================================================== UI

    private fun buildUi() {
        root = FrameLayout(this)
        buildHome()
        buildDrawer()
        buildPanel()
        buildTaskbar()
        buildMenu()
        buildToast()

        dragCatcher = View(this)
        dragCatcher.setOnDragListener { _, e ->
            when (e.action) {
                DragEvent.ACTION_DROP -> handleDrop(e.x, e.y)
                DragEvent.ACTION_DRAG_ENDED -> drag = null
            }
            true
        }
        root.addView(dragCatcher, FrameLayout.LayoutParams(MATCH, MATCH))

        // yukarı kaydır = çekmece, aşağı kaydır = bildirim paneli
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) { showSettings() }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (drawerOpen || panelOpen) return false
                if (vy < -800f) { openDrawer(); return true }
                if (vy > 800f) { openPanel(0); return true }
                return false
            }
        })
        root.setOnTouchListener { _, e -> gd.onTouchEvent(e) }

        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            insetTop = b.top
            insetBottom = b.bottom
            applyInsets()
            val ime = ins.isVisible(WindowInsets.Type.ime())
            if (ime != imeVisible) {
                imeVisible = ime
                if (ime) hideTaskbar() else showTaskbar()
            }
            ins
        }
    }

    private fun applyInsets() {
        val bottomSpace = insetBottom + dp(barH + 12 + 16)
        homeCol.setPadding(dp(16), insetTop + dp(16), dp(16), bottomSpace)
        drawerContent.setPadding(dp(16), insetTop + dp(16), dp(16), 0)
        drawerGrid.setPadding(0, 0, dp(14), bottomSpace)
        (sheet.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop + dp(12)
        sheet.requestLayout()
        (taskbar.layoutParams as FrameLayout.LayoutParams).bottomMargin = insetBottom + dp(12)
        taskbar.requestLayout()
        (toastPanel.layoutParams as FrameLayout.LayoutParams).bottomMargin = insetBottom + dp(barH + 12 + 70)
        toastPanel.requestLayout()
        applyClockPos()
    }

    // ---------------------------------------------------------------- ana ekran

    private fun buildHome() {
        homeLayer = FrameLayout(this)
        homeCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeCol.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))

        favGrid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(6), dp(10), dp(6), dp(10))
        }
        favPanel = BlurPanel(this, 28f).apply {
            addView(favGrid, FrameLayout.LayoutParams(MATCH, WRAP))
            visibility = View.GONE
        }
        homeCol.addView(favPanel, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        val searchPanel = BlurPanel(this, 26f).apply {
            isClickable = true
            setOnClickListener { openDrawer(true) }
        }
        val sRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        sRow.addView(icon(R.drawable.ic_search, 20, SOFT))
        sRow.addView(TextView(this).apply {
            text = "Ara"; textSize = 15f; setTextColor(SOFT)
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })
        searchPanel.addView(sRow, FrameLayout.LayoutParams(MATCH, MATCH))
        homeCol.addView(searchPanel, LinearLayout.LayoutParams(MATCH, dp(54)))
        homeLayer.addView(homeCol, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---- sürüklenebilir saat kartı: beyaz blur zemin, saat üstünde
        val clock = TextClock(this).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"
            textSize = 56f
            setTextColor(INK)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 14f
            setTextColor(SOFT)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(clock)
        col.addView(date)
        clockCard = BlurPanel(this, 28f, 44f, Color.argb(115, 255, 255, 255), Color.argb(170, 255, 255, 255)).apply {
            addView(col, FrameLayout.LayoutParams(WRAP, WRAP))
            isClickable = true
        }
        homeLayer.addView(clockCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START))

        makeDraggable(clockCard, "cx2", "cy2")
        buildWidgets()
        applyClockPos()

        root.addView(homeLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    /** Kartı parmakla taşınabilir yapar, konumu ekranın oranı olarak kaydeder. */
    private fun makeDraggable(card: BlurPanel, kx: String, ky: String) {
        var sx = 0f
        var sy = 0f
        var ml = 0
        var mt = 0
        card.setOnTouchListener { v, e ->
            val lp = v.layoutParams as FrameLayout.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ml = lp.leftMargin
                    mt = lp.topMargin
                    v.parent.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    val maxX = (screenW() - v.width).coerceAtLeast(0)
                    val maxY = (screenH() - v.height).coerceAtLeast(0)
                    lp.leftMargin = (ml + (e.rawX - sx)).toInt().coerceIn(0, maxX)
                    lp.topMargin = (mt + (e.rawY - sy)).toInt().coerceIn(0, maxY)
                    v.layoutParams = lp
                    card.refresh()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    prefs.edit()
                        .putFloat(kx, lp.leftMargin.toFloat() / screenW())
                        .putFloat(ky, lp.topMargin.toFloat() / screenH())
                        .apply()
                }
            }
            true
        }
    }

    private fun applyPos(card: BlurPanel, kx: String, ky: String, defX: Int, defY: Int) {
        val fx = prefs.getFloat(kx, -1f)
        val fy = prefs.getFloat(ky, -1f)
        val lp = card.layoutParams as FrameLayout.LayoutParams
        if (fx < 0f || fy < 0f) {
            lp.leftMargin = defX.coerceAtLeast(0)
            lp.topMargin = defY.coerceAtLeast(0)
        } else {
            lp.leftMargin = (fx * screenW()).toInt().coerceIn(0, (screenW() - dp(100)).coerceAtLeast(0))
            lp.topMargin = (fy * screenH()).toInt().coerceIn(0, (screenH() - dp(80)).coerceAtLeast(0))
        }
        card.layoutParams = lp
        card.refresh()
    }

    private fun applyClockPos() {
        applyPos(clockCard, "cx2", "cy2", dp(16), insetTop + dp(16))
        applyPos(batCard, "bx", "by", screenW() - dp(16) - dp(128), insetTop + dp(16))
        applyPos(calCard, "kx", "ky", dp(16), insetTop + dp(140))
    }

    // ---------------------------------------------------------------- widget'lar (pil, takvim)

    private fun buildWidgets() {
        batSub = TextView(this).apply { text = "Pil"; textSize = 12f; setTextColor(SOFT) }
        batText = TextView(this).apply { textSize = 28f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD }
        batBar = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(accent())
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(60, 30, 58, 95))
        }
        val bcol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(14))
        }
        bcol.addView(batSub)
        bcol.addView(batText)
        bcol.addView(batBar, LinearLayout.LayoutParams(dp(96), dp(6)).apply { topMargin = dp(8) })
        batCard = BlurPanel(this, 24f).apply {
            isClickable = true
            addView(bcol, FrameLayout.LayoutParams(WRAP, WRAP))
        }
        homeLayer.addView(batCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START))
        makeDraggable(batCard, "bx", "by")

        calTitle = TextView(this).apply { textSize = 14f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD }
        calGrid = GridLayout(this).apply { columnCount = 7 }
        val ccol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }
        ccol.addView(calTitle, LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(6); marginStart = dp(4) })
        ccol.addView(calGrid)
        calCard = BlurPanel(this, 24f).apply {
            isClickable = true
            addView(ccol, FrameLayout.LayoutParams(WRAP, WRAP))
        }
        homeLayer.addView(calCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START))
        makeDraggable(calCard, "kx", "ky")

        applyWidgetVis()
    }

    private fun applyWidgetVis() {
        batCard.visibility = if (prefs.getBoolean("w_bat", true)) View.VISIBLE else View.GONE
        calCard.visibility = if (prefs.getBoolean("w_cal", true)) View.VISIBLE else View.GONE
    }

    private fun calCell(t: String, color: Int, today: Boolean): TextView = TextView(this).apply {
        text = t
        textSize = 11f
        gravity = Gravity.CENTER
        layoutParams = ViewGroup.LayoutParams(dp(24), dp(22))
        if (today) {
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent()) }
        } else {
            setTextColor(color)
        }
    }

    private fun renderCalendar() {
        val cal = java.util.Calendar.getInstance()
        val today = cal.get(java.util.Calendar.DAY_OF_MONTH)
        val title = java.text.SimpleDateFormat("LLLL yyyy", java.util.Locale.getDefault()).format(cal.time)
        calTitle.text = title.replaceFirstChar { it.uppercase() }
        calGrid.removeAllViews()
        for (h in arrayOf("P", "S", "Ç", "P", "C", "C", "P")) calGrid.addView(calCell(h, SOFT, false))
        val first = cal.clone() as java.util.Calendar
        first.set(java.util.Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
        val days = first.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        repeat(offset) { calGrid.addView(calCell("", INK, false)) }
        for (d in 1..days) calGrid.addView(calCell(d.toString(), INK, d == today))
    }

    private val batReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { updateBattery(i) }
    }

    private fun updateBattery(i: Intent?) {
        if (i == null) return
        val lvl = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
        if (lvl < 0 || scale <= 0) return
        val pct = lvl * 100 / scale
        batText.text = "%$pct"
        batBar.progress = pct
        batSub.text = if (st == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
            st == android.os.BatteryManager.BATTERY_STATUS_FULL) "Şarj oluyor" else "Pil"
    }

    // ---------------------------------------------------------------- çekmece

    private fun buildDrawer() {
        drawer = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            isClickable = true
            setBackgroundColor(Color.argb(if (Fx.blur) 120 else 238, 255, 255, 255))
        }
        drawerContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val dSearch = BlurPanel(this, 26f)
        val dRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        dRow.addView(icon(R.drawable.ic_search, 20, SOFT))
        searchEdit = EditText(this).apply {
            hint = "Uygulama ara"
            setHintTextColor(SOFT)
            setTextColor(INK)
            textSize = 16f
            background = null
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnFocusChangeListener { _, has -> if (has) hideTaskbar() else showTaskbar() }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ ->
                adapter.items.firstOrNull()?.let { launch(it) }
                true
            }
        }
        dRow.addView(searchEdit, LinearLayout.LayoutParams(MATCH, MATCH).apply { marginStart = dp(12) })
        dSearch.addView(dRow, FrameLayout.LayoutParams(MATCH, MATCH))
        drawerContent.addView(dSearch, LinearLayout.LayoutParams(MATCH, dp(54)))

        drawerGrid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(14)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, p, _ -> launch(this@MainActivity.adapter.items[p]) }
            setOnItemLongClickListener { _, v, p, _ ->
                startDrag(v, this@MainActivity.adapter.items[p].key, Src.DRAWER)
                true
            }
        }
        recentGrid = GridLayout(this).apply { columnCount = 4; setPadding(dp(6), dp(2), dp(6), dp(8)) }
        val rcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rcol.addView(TextView(this).apply {
            text = "Sık kullanılanlar"
            textSize = 12f
            setTextColor(SOFT)
            setPadding(dp(16), dp(10), dp(16), dp(2))
        })
        rcol.addView(recentGrid)
        recentPanel = BlurPanel(this, 24f).apply {
            visibility = View.GONE
            addView(rcol, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        drawerContent.addView(recentPanel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        val holder = FrameLayout(this)
        holder.addView(drawerGrid, FrameLayout.LayoutParams(MATCH, MATCH))
        buildIndexStrip(holder)
        drawerContent.addView(holder, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(12) })
        drawer.addView(drawerContent, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun updateHomeBlur() {
        homeLayer.setRenderEffect(
            if (Fx.blur && (drawerOpen || panelOpen || menuOpen)) RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP) else null
        )
    }

    // ---------------------------------------------------------------- QwLauncher menüsü (uzun bas)

    private fun buildMenu() {
        menuLayer = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            isClickable = true
            setBackgroundColor(Color.argb(60, 20, 40, 70))
            setOnClickListener { closeMenu() }
        }
        menuCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(14), dp(8), dp(8))
        }
        val card = BlurPanel(this, 28f, 60f, Color.argb(38, 255, 255, 255), Color.argb(120, 255, 255, 255)).apply {
            isClickable = true
            addView(menuCol, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        menuLayer.addView(card, FrameLayout.LayoutParams(dp(290), WRAP, Gravity.CENTER))
        root.addView(menuLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun menuRow(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        setTextColor(INK)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        foreground = ripple()
        isClickable = true
        setOnClickListener { closeMenu(); action() }
    }

    /** Tüm menüler (QwLauncher menüsü, uygulama menüsü) bu şeffaf, yuvarlak, bulanık karttan açılır. */
    private fun openGlassMenu(title: String, items: List<MenuItem>) {
        if (menuOpen) return
        menuCol.removeAllViews()
        menuCol.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(SOFT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(16), 0, dp(16), dp(6))
        })
        for (it in items) menuCol.addView(menuRow(it.label, it.action))
        menuOpen = true
        menuLayer.visibility = View.VISIBLE
        menuLayer.alpha = 0f
        menuLayer.animate().alpha(1f).setDuration(180).start()
        updateHomeBlur()
    }

    private fun showSettings() {
        if (menuOpen || drawerOpen || panelOpen) return
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Duvar kağıdını değiştir") { pickWallpaper() })
        if (Wall.bitmap != null) {
            items.add(MenuItem("Varsayılan duvar kağıdı") { Wall.reset(this); recreate() })
        }
        val batOn = prefs.getBoolean("w_bat", true)
        val calOn = prefs.getBoolean("w_cal", true)
        items.add(MenuItem(if (batOn) "Pil kartını gizle" else "Pil kartını göster") {
            prefs.edit().putBoolean("w_bat", !batOn).apply()
            applyWidgetVis()
        })
        items.add(MenuItem(if (calOn) "Takvim kartını gizle" else "Takvim kartını göster") {
            prefs.edit().putBoolean("w_cal", !calOn).apply()
            applyWidgetVis()
        })
        val hid = hiddenKeys()
        val hiddenCount = apps.count { it.key in hid }
        if (hiddenCount > 0) {
            items.add(MenuItem("Gizli uygulamalar ($hiddenCount)") { showHiddenMenu() })
        }
        items.add(MenuItem(if (Fx.blur) "Blur: açık (kapat)" else "Blur: kapalı (aç)") {
            prefs.edit().putBoolean("blur", !Fx.blur).apply()
            recreate()
        })
        items.add(MenuItem("Kart konumlarını sıfırla") {
            val e = prefs.edit()
            for (k in arrayOf("cx2", "cy2", "bx", "by", "kx", "ky")) e.remove(k)
            e.apply()
            applyClockPos()
        })
        openGlassMenu("QwLauncher", items)
    }

    private fun showHiddenMenu() {
        val hid = hiddenKeys()
        val items = ArrayList<MenuItem>()
        for (a in apps.filter { it.key in hid }.take(8)) {
            items.add(MenuItem("Göster: ${a.label}") {
                val h = hiddenKeys()
                h.remove(a.key)
                saveHidden(h)
                applyFilter(searchEdit.text.toString())
            })
        }
        openGlassMenu("Gizli uygulamalar", items)
    }

    // ---------------------------------------------------------------- cam stilli mesaj (toast yerine)

    private fun buildToast() {
        toastText = TextView(this).apply {
            textSize = 14f
            setTextColor(INK)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        toastPanel = BlurPanel(this, 22f, 60f, Color.argb(60, 255, 255, 255), Color.argb(140, 255, 255, 255)).apply {
            visibility = View.GONE
            alpha = 0f
            addView(toastText, FrameLayout.LayoutParams(WRAP, WRAP))
        }
        root.addView(toastPanel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(150)
            marginStart = dp(24)
            marginEnd = dp(24)
        })
    }

    private val toastHide = Runnable {
        toastPanel.animate().alpha(0f).setDuration(200).withEndAction {
            toastPanel.visibility = View.GONE
        }.start()
    }

    private fun toast(msg: String) {
        toastText.text = msg
        toastPanel.removeCallbacks(toastHide)
        toastPanel.animate().cancel()
        toastPanel.visibility = View.VISIBLE
        toastPanel.animate().alpha(1f).setDuration(150).start()
        toastPanel.refresh()
        toastPanel.postDelayed(toastHide, 1800)
    }

    private fun closeMenu() {
        if (!menuOpen) return
        menuOpen = false
        updateHomeBlur()
        menuLayer.animate().alpha(0f).setDuration(150).withEndAction {
            if (!menuOpen) menuLayer.visibility = View.GONE
        }.start()
    }

    private fun pickWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
        try {
            startActivityForResult(i, 77)
        } catch (e: Exception) {
            toast("Galeri bulunamadı")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            if (Wall.save(this, uri)) recreate()
            else toast("Görsel okunamadı")
        }
    }

    private fun hideTaskbar() {
        val lp = taskbar.layoutParams as FrameLayout.LayoutParams
        taskbar.animate().cancel()
        taskbar.animate()
            .translationY((taskbar.height + lp.bottomMargin + dp(24)).toFloat())
            .setDuration(260)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
    }

    private fun showTaskbar() {
        taskbar.animate().cancel()
        taskbar.animate()
            .translationY(0f)
            .setDuration(260)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .withEndAction { taskbar.refresh() }
            .start()
    }

    private fun toggleDrawer() { if (drawerOpen) closeDrawer() else openDrawer() }

    private fun openDrawer(focus: Boolean = false) {
        if (panelOpen) closePanel()
        if (!drawerOpen) {
            drawerOpen = true
            searchEdit.setText("")
            drawer.visibility = View.VISIBLE
            drawer.alpha = 0f
            drawer.animate().alpha(1f).setDuration(220).start()
            updateHomeBlur()
        }
        if (focus) {
            searchEdit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchEdit, 0)
        }
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchEdit.windowToken, 0)
        searchEdit.clearFocus()
        showTaskbar()
        updateHomeBlur()
        drawer.animate().alpha(0f).setDuration(180).withEndAction {
            if (!drawerOpen) drawer.visibility = View.GONE
        }.start()
    }

    // ---------------------------------------------------------------- bildirim + ses paneli

    private fun buildPanel() {
        panelLayer = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            isClickable = true
            setBackgroundColor(Color.argb(if (Fx.blur) 60 else 150, 255, 255, 255))
            setOnClickListener { closePanel() }
        }
        sheet = BlurPanel(this, 30f, 60f).apply { isClickable = true }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panelTitle = TextView(this).apply {
            textSize = 18f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
        }
        clearBtn = TextView(this).apply {
            text = "Temizle"; textSize = 13f; setTextColor(SOFT)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { try { NotifService.instance?.cancelAllNotifications() } catch (_: Exception) {} }
        }
        head.addView(panelTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(clearBtn)
        head.addView(tbBtn(R.drawable.ic_bell) { showPanelMode(0) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        head.addView(tbBtn(R.drawable.ic_volume) { showPanelMode(1) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })

        val body = FrameLayout(this)
        notifList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        notifScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(notifList, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        body.addView(notifScroll, FrameLayout.LayoutParams(MATCH, MATCH))

        volumeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        addSlider("Medya", R.drawable.ic_music, AudioManager.STREAM_MUSIC)
        addSlider("Zil", R.drawable.ic_bell, AudioManager.STREAM_RING)
        addSlider("Alarm", R.drawable.ic_clock, AudioManager.STREAM_ALARM)
        body.addView(volumeBox, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        sheet.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        panelLayer.addView(sheet, FrameLayout.LayoutParams(
            MATCH, (resources.displayMetrics.heightPixels * 0.62f).toInt(), Gravity.TOP
        ).apply { marginStart = dp(12); marginEnd = dp(12) })
        root.addView(panelLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun addSlider(label: String, res: Int, stream: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        row.addView(icon(res, 22, INK))
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(SOFT) })
        val seek = SeekBar(this).apply {
            max = audio.getStreamMaxVolume(stream)
            progress = audio.getStreamVolume(stream)
            progressTintList = ColorStateList.valueOf(accent())
            thumbTintList = ColorStateList.valueOf(accent())
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(70, 30, 58, 95))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        try { audio.setStreamVolume(stream, p, 0) } catch (_: SecurityException) {}
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        c.addView(seek, LinearLayout.LayoutParams(MATCH, WRAP))
        seekList.add(seek to stream)
        row.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        volumeBox.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun togglePanel(mode: Int) {
        if (panelOpen && panelMode == mode) closePanel() else openPanel(mode)
    }

    private fun openPanel(mode: Int) {
        if (drawerOpen) closeDrawer()
        if (!panelOpen) {
            panelOpen = true
            panelLayer.visibility = View.VISIBLE
            panelLayer.alpha = 0f
            panelLayer.animate().alpha(1f).setDuration(220).start()
            updateHomeBlur()
        }
        showPanelMode(mode)
    }

    private fun closePanel() {
        if (!panelOpen) return
        panelOpen = false
        updateHomeBlur()
        panelLayer.animate().alpha(0f).setDuration(180).withEndAction {
            if (!panelOpen) panelLayer.visibility = View.GONE
        }.start()
    }

    private fun showPanelMode(mode: Int) {
        panelMode = mode
        panelTitle.text = if (mode == 0) "Bildirimler" else "Ses"
        notifScroll.visibility = if (mode == 0) View.VISIBLE else View.GONE
        volumeBox.visibility = if (mode == 1) View.VISIBLE else View.GONE
        clearBtn.visibility = if (mode == 0) View.VISIBLE else View.GONE
        if (mode == 0) refreshNotifs()
        else seekList.forEach { (s, st) -> s.progress = audio.getStreamVolume(st) }
    }

    private fun notifAccessEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return s.contains(packageName)
    }

    private fun hintCard(text: String, btn: String?, action: (() -> Unit)?) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply { setColor(Color.argb(120, 255, 255, 255)); cornerRadius = dpf(18f) }
        }
        c.addView(TextView(this).apply { this.text = text; textSize = 14f; setTextColor(INK) })
        if (btn != null && action != null) {
            c.addView(TextView(this).apply {
                this.text = btn; textSize = 14f; setTextColor(accent()); typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(12), 0, 0)
                setOnClickListener { action() }
            })
        }
        notifList.addView(c, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun refreshNotifs() {
        notifList.removeAllViews()
        if (!notifAccessEnabled()) {
            hintCard("Bildirimleri burada göstermek için bildirim erişimi vermen gerekiyor.", "Erişimi aç") {
                tryStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            return
        }
        val list: List<StatusBarNotification> = try {
            (NotifService.instance?.activeNotifications ?: emptyArray())
                .filter { (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
                .sortedByDescending { it.postTime }
        } catch (e: Exception) { emptyList() }
        if (list.isEmpty()) {
            hintCard("Bildirim yok", null, null)
            return
        }
        for (sbn in list) {
            notifList.addView(notifItem(sbn), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
    }

    private fun notifItem(sbn: StatusBarNotification): View {
        val n = sbn.notification
        val pm = packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(6), dp(10))
            background = GradientDrawable().apply { setColor(Color.argb(120, 255, 255, 255)); cornerRadius = dpf(18f) }
            isClickable = true
            setOnClickListener {
                try { n.contentIntent?.send() } catch (_: Exception) {}
                if ((n.flags and Notification.FLAG_AUTO_CANCEL) != 0) {
                    try { NotifService.instance?.cancelNotification(sbn.key) } catch (_: Exception) {}
                }
                closePanel()
            }
        }
        val ic = ImageView(this).apply { setImageDrawable(pkgIcon(sbn.packageName)) }
        row.addView(ic, LinearLayout.LayoutParams(dp(36), dp(36)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply { this.text = label; textSize = 11f; setTextColor(SOFT); maxLines = 1 })
        col.addView(TextView(this).apply {
            this.text = title; textSize = 14f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        if (text.isNotBlank()) {
            col.addView(TextView(this).apply {
                this.text = text; textSize = 13f; setTextColor(INK)
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
        }
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12) })

        val x = icon(R.drawable.ic_x, 18, SOFT).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { try { NotifService.instance?.cancelNotification(sbn.key) } catch (_: Exception) {} }
        }
        row.addView(x, LinearLayout.LayoutParams(dp(34), dp(34)))
        return row
    }

    // ---------------------------------------------------------------- görev çubuğu

    private fun ripple() = RippleDrawable(
        ColorStateList.valueOf(Color.argb(50, 30, 58, 95)), null,
        GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dpf(12f) }
    )

    private fun tbBtn(res: Int, action: () -> Unit): FrameLayout = FrameLayout(this).apply {
        addView(icon(res, 22), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        foreground = ripple()
        isClickable = true
        setOnClickListener { action() }
    }

    private fun buildTaskbar() {
        taskbar = BlurPanel(this, 22f)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(tbBtn(R.drawable.ic_grid) { toggleDrawer() },
            LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(6) })
        barRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(barRow, LinearLayout.LayoutParams(0, MATCH, 1f))
        bar.addView(tbBtn(R.drawable.ic_bell) { togglePanel(0) }, LinearLayout.LayoutParams(dp(34), dp(40)))
        bar.addView(tbBtn(R.drawable.ic_volume) { togglePanel(1) },
            LinearLayout.LayoutParams(dp(34), dp(40)).apply { marginEnd = dp(6) })
        taskbar.addView(bar, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(taskbar, FrameLayout.LayoutParams(MATCH, dp(barH), Gravity.BOTTOM).apply {
            marginStart = dp(16); marginEnd = dp(16)
        })
    }

    private val defaultBar = "sys:phone\nsys:message\nsys:camera\nsys:browser"

    private fun barKeys(): MutableList<String> =
        (prefs.getString("bar", defaultBar) ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun saveBar(l: List<String>) = prefs.edit().putString("bar", l.joinToString("\n")).apply()

    private fun resolveSys(key: String): App? {
        val intent = when (key) {
            "sys:phone" -> Intent(Intent.ACTION_DIAL)
            "sys:message" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            "sys:camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "sys:browser" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER)
            else -> return null
        }
        val ri = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) ?: return null
        val pkg = ri.activityInfo.packageName
        return apps.find { it.component.packageName == pkg }
    }

    private fun barApp(key: String): App? =
        if (key.startsWith("sys:")) resolveSys(key) else apps.find { it.key == key }

    private fun renderBar() {
        barRow.removeAllViews()
        for (key in barKeys()) {
            val app = barApp(key) ?: continue
            barRow.addView(barCell(key, app), LinearLayout.LayoutParams(dp(40), MATCH))
        }
    }

    private fun barCell(key: String, app: App): FrameLayout = FrameLayout(this).apply {
        val iv = ImageView(context).apply { setImageDrawable(iconFor(app)) }
        addView(iv, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
        foreground = ripple()
        isClickable = true
        contentDescription = app.label
        setOnClickListener { launch(app) }
        setOnLongClickListener { startDrag(this, key, Src.BAR); true }
    }

    private fun pinToBar(key: String, index: Int) {
        val l = barKeys()
        val old = l.indexOf(key)
        var idx = index
        if (old in 0 until idx) idx -= 1
        if (old >= 0) l.removeAt(old)
        else if (l.size >= maxBar) {
            toast("Görev çubuğu dolu (en fazla $maxBar)")
            return
        }
        l.add(idx.coerceIn(0, l.size), key)
        saveBar(l)
        renderBar()
    }

    private fun unpin(key: String) {
        val l = barKeys()
        if (l.remove(key)) { saveBar(l); renderBar() }
    }

    // ---------------------------------------------------------------- sürükle-bırak

    private fun startDrag(v: View, key: String, src: Src) {
        drag = DragInfo(key, src, v)
        v.startDragAndDrop(ClipData.newPlainText("app", key), View.DragShadowBuilder(v), null, 0)
    }

    private fun rootRect(v: View): Rect {
        val a = IntArray(2)
        val r = IntArray(2)
        v.getLocationInWindow(a)
        root.getLocationInWindow(r)
        val l = a[0] - r[0]
        val t = a[1] - r[1]
        return Rect(l, t, l + v.width, t + v.height)
    }

    private fun indexFor(x: Float): Int {
        var idx = 0
        for (i in 0 until barRow.childCount) {
            val rc = rootRect(barRow.getChildAt(i))
            if (rc.exactCenterX() < x) idx = i + 1
        }
        return idx
    }

    private fun handleDrop(x: Float, y: Float) {
        val d = drag ?: return
        val a = rootRect(d.anchor).apply { inset(-dp(10), -dp(10)) }
        if (a.contains(x.toInt(), y.toInt())) {
            // yerinde bırakıldı = uzun basma menüsü
            showMenu(d.key, d.anchor)
            return
        }
        val inBar = x >= taskbar.left && x <= taskbar.right && y >= taskbar.top && y <= taskbar.bottom
        if (inBar) {
            pinToBar(d.key, indexFor(x))
            return
        }
        when (d.src) {
            Src.DRAWER -> { addFavorite(d.key); closeDrawer() }
            Src.BAR -> unpin(d.key)
            Src.HOME -> {}
        }
    }

    // ---------------------------------------------------------------- uygulamalar

    private val bmpCache = HashMap<String, Bitmap>()

    private fun iconFor(app: App): Drawable =
        BitmapDrawable(resources, bmpCache.getOrPut(app.key) { roundedIconBitmap(app.icon, 160) })

    private fun pkgIcon(pkg: String): Drawable {
        val bmp: Bitmap? = bmpCache["pkg:$pkg"] ?: try {
            roundedIconBitmap(packageManager.getApplicationIcon(pkg), 160).also { bmpCache["pkg:$pkg"] = it }
        } catch (e: Exception) { null }
        return if (bmp != null) BitmapDrawable(resources, bmp) else ColorDrawable(accent())
    }

    private fun loadApps() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        bmpCache.clear()
        apps = pm.queryIntentActivities(i, 0)
            .map { App(it.loadLabel(pm).toString(), ComponentName(it.activityInfo.packageName, it.activityInfo.name), it.loadIcon(pm)) }
            .filter { it.component.packageName != packageName }
            .sortedWith(compareBy<App>({ sortBucket(it.label) }, { it.label.lowercase() }))
        applyFilter(searchEdit.text.toString())
        renderFavorites()
        renderBar()
    }

    private fun applyFilter(q: String) {
        val vis = visibleApps()
        val blank = q.isBlank()
        adapter.items = if (blank) vis else vis.filter { it.label.contains(q.trim(), ignoreCase = true) }
        adapter.notifyDataSetChanged()
        indexStrip.visibility = if (blank && adapter.items.size > 12) View.VISIBLE else View.GONE
        renderRecents(blank)
    }

    private fun launch(app: App) {
        bumpUsage(app.key)
        tryStart(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        closeDrawer()
    }

    private fun tryStart(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Uygulama bulunamadı")
        }
    }

    private fun appCell(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(4), dp(2), dp(4))
        addView(ImageView(context), LinearLayout.LayoutParams(dp(52), dp(52)))
        addView(TextView(context).apply {
            textSize = 11f; setTextColor(INK); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
    }

    private fun bind(cell: LinearLayout, app: App) {
        (cell.getChildAt(0) as ImageView).setImageDrawable(iconFor(app))
        (cell.getChildAt(1) as TextView).text = app.label
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<App> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? LinearLayout) ?: appCell()
            bind(v, items[position])
            return v
        }
    }

    // ---------------------------------------------------------------- favoriler (ana ekran)

    private fun favKeys(): MutableList<String> =
        (prefs.getString("favs", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun saveFavs(l: List<String>) = prefs.edit().putString("favs", l.joinToString("\n")).apply()

    private fun addFavorite(key: String) {
        val l = favKeys()
        if (l.contains(key)) return
        if (l.size >= 8) {
            toast("Ana ekranda en fazla 8 uygulama")
            return
        }
        l.add(key)
        saveFavs(l)
        renderFavorites()
    }

    private fun renderFavorites() {
        favGrid.removeAllViews()
        val list = favKeys().mapNotNull { k -> apps.find { it.key == k } }.take(8)
        favPanel.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (app in list) {
            val cell = appCell()
            bind(cell, app)
            cell.setOnClickListener { launch(app) }
            cell.setOnLongClickListener { startDrag(cell, app.key, Src.HOME); true }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setMargins(0, dp(6), 0, dp(6))
            favGrid.addView(cell, lp)
        }
    }

    private fun showMenu(key: String, anchor: View) {
        val app = apps.find { it.key == key } ?: if (key.startsWith("sys:")) resolveSys(key) else null
        val inBar = barKeys().contains(key)
        val fk = app?.key ?: key
        val isFav = favKeys().contains(fk)
        val items = ArrayList<MenuItem>()
        if (app != null) {
            items.add(MenuItem(if (isFav) "Ana ekrandan kaldır" else "Ana ekrana ekle") {
                val l = favKeys()
                if (isFav) { l.remove(fk); saveFavs(l); renderFavorites() } else addFavorite(fk)
            })
        }
        items.add(MenuItem(if (inBar) "Görev çubuğundan kaldır" else "Görev çubuğuna ekle") {
            if (inBar) unpin(key) else pinToBar(key, Int.MAX_VALUE)
        })
        if (app != null) {
            val hiddenNow = hiddenKeys().contains(fk)
            items.add(MenuItem(if (hiddenNow) "Uygulamayı göster" else "Uygulamayı gizle") {
                val h = hiddenKeys()
                if (hiddenNow) h.remove(fk) else h.add(fk)
                saveHidden(h)
                applyFilter(searchEdit.text.toString())
                toast(if (hiddenNow) "${app.label} gösterildi" else "${app.label} gizlendi")
            })
            val pkg = Uri.parse("package:${app.component.packageName}")
            items.add(MenuItem("Uygulama bilgisi") { tryStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) })
            items.add(MenuItem("Kaldır") { tryStart(Intent(Intent.ACTION_DELETE, pkg)) })
        }
        openGlassMenu(app?.label ?: "Uygulama", items)
    }

    // ---------------------------------------------------------------- gizli uygulamalar, kullanım sayısı

    private fun hiddenKeys(): MutableSet<String> =
        (prefs.getString("hidden", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableSet()

    private fun saveHidden(set: Set<String>) = prefs.edit().putString("hidden", set.joinToString("\n")).apply()

    private fun visibleApps(): List<App> {
        val h = hiddenKeys()
        return apps.filter { it.key !in h }
    }

    private fun usageMap(): MutableMap<String, Int> {
        val m = HashMap<String, Int>()
        for (line in (prefs.getString("usage", "") ?: "").split("\n")) {
            val p = line.split("\t")
            if (p.size == 2) m[p[0]] = p[1].toIntOrNull() ?: 0
        }
        return m
    }

    private fun bumpUsage(key: String) {
        val m = usageMap()
        m[key] = (m[key] ?: 0) + 1
        prefs.edit().putString("usage", m.entries.joinToString("\n") { "${it.key}\t${it.value}" }).apply()
    }

    private fun renderRecents(blank: Boolean) {
        recentGrid.removeAllViews()
        val u = usageMap()
        val top = visibleApps().filter { (u[it.key] ?: 0) > 0 }.sortedByDescending { u[it.key] ?: 0 }.take(4)
        recentPanel.visibility = if (blank && top.isNotEmpty()) View.VISIBLE else View.GONE
        for (app in top) {
            val cell = appCell()
            bind(cell, app)
            cell.setOnClickListener { launch(app) }
            cell.setOnLongClickListener { startDrag(cell, app.key, Src.DRAWER); true }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setMargins(0, dp(4), 0, dp(4))
            recentGrid.addView(cell, lp)
        }
    }

    // ---------------------------------------------------------------- A-Z hızlı kaydırma şeridi

    private val letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#"

    private fun bucket(label: String): Char {
        val c = label.trim().firstOrNull()?.uppercaseChar() ?: return '#'
        val m = when (c) {
            'Ç' -> 'C'
            'Ğ' -> 'G'
            'İ' -> 'I'
            'Ö' -> 'O'
            'Ş' -> 'S'
            'Ü' -> 'U'
            else -> c
        }
        return if (m in 'A'..'Z') m else '#'
    }

    private fun sortBucket(label: String): Char {
        val b = bucket(label)
        return if (b == '#') '~' else b
    }

    private fun jumpToLetter(ch: Char) {
        val list = adapter.items
        if (list.isEmpty()) return
        val key = if (ch == '#') '~' else ch
        var idx = list.indexOfFirst { sortBucket(it.label) >= key }
        if (idx < 0) idx = list.size - 1
        drawerGrid.setSelection(idx)
    }

    private fun buildIndexStrip(holder: FrameLayout) {
        indexStrip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
        }
        for (ch in letters) {
            indexStrip.addView(TextView(this).apply {
                text = ch.toString()
                textSize = 10f
                setTextColor(SOFT)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(22), 0, 1f))
        }
        holder.addView(indexStrip, FrameLayout.LayoutParams(dp(22), MATCH, Gravity.END))

        letterBubble = TextView(this).apply {
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.argb(150, 30, 58, 95)); cornerRadius = dpf(20f) }
            visibility = View.GONE
        }
        holder.addView(letterBubble, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER))

        indexStrip.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    val f = (e.y / v.height.coerceAtLeast(1)).coerceIn(0f, 0.999f)
                    val ch = letters[(f * letters.length).toInt()]
                    jumpToLetter(ch)
                    letterBubble.text = ch.toString()
                    letterBubble.visibility = View.VISIBLE
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> letterBubble.visibility = View.GONE
            }
            true
        }
    }
}
