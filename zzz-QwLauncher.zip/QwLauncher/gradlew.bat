@echo off
echo Bu proje Linux/macOS icin gradlew kullanir. Windows'ta Android Studio ile acin.
exit /b 1
