package com.sade.launcher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.Drawable

/** Mavi-beyaz dalga arka plan (referans görsele benzer, daha belirgin). */
class WaveBackground : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(205, 255, 255, 255); style = Paint.Style.FILL
    }
    private val deep = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(80, 70, 140, 205); style = Paint.Style.FILL
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 80, 145, 200); style = Paint.Style.STROKE; strokeWidth = 2.5f
    }
    private val path = Path()

    override fun onBoundsChange(b: Rect) {
        fill.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(0xFFE3F2FC.toInt(), 0xFFBFE0F5.toInt(), 0xFF8FC4E8.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun curve(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float,
                      x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset(); path.moveTo(x0, y0); path.cubicTo(x1, y1, x2, y2, x3, y3)
        c.drawPath(path, line)
    }

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        c.drawRect(bounds, fill)

        // alttaki koyu mavi dalga
        path.reset()
        path.moveTo(w * .30f, h)
        path.cubicTo(w * .42f, h * .84f, w * .80f, h * .90f, w, h * .70f)
        path.lineTo(w, h); path.close()
        c.drawPath(path, deep)

        // sol beyaz dalga
        path.reset()
        path.moveTo(0f, h * .10f)
        path.cubicTo(w * .38f, h * .20f, w * .10f, h * .42f, w * .40f, h * .58f)
        path.cubicTo(w * .55f, h * .67f, w * .48f, h * .86f, w * .42f, h)
        path.lineTo(0f, h); path.close()
        c.drawPath(path, wave)

        // sağ beyaz dalga
        path.reset()
        path.moveTo(w, 0f); path.lineTo(w * .78f, 0f)
        path.cubicTo(w * .74f, h * .12f, w * .95f, h * .16f, w * .86f, h * .30f)
        path.cubicTo(w * .78f, h * .42f, w * .98f, h * .50f, w * .96f, h * .70f)
        path.cubicTo(w * .95f, h * .80f, w * .90f, h * .86f, w, h * .90f)
        path.close()
        c.drawPath(path, wave)

        // ince çizgiler
        curve(c, 0f, h * .16f, w * .34f, h * .26f, w * .12f, h * .46f, w * .36f, h * .64f)
        curve(c, w * .08f, 0f, w * .40f, h * .14f, w * .22f, h * .36f, w * .46f, h * .55f)
        curve(c, w * .80f, 0f, w * .70f, h * .16f, w * .92f, h * .24f, w * .84f, h * .40f)
        curve(c, w * .98f, h * .20f, w * .80f, h * .34f, w * .90f, h * .56f, w, h * .66f)
        curve(c, 0f, h * .66f, w * .16f, h * .74f, w * .20f, h * .88f, w * .30f, h)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
